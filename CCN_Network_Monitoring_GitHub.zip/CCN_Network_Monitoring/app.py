
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

from network_monitor import (
    measure_latency,
    calculate_jitter,
    calculate_packet_loss,
    measure_throughput,
    save_test_result,
)

st.set_page_config(
    page_title="CCN Network Performance Monitor",
    page_icon="🌐",
    layout="wide"
)

st.title("🌐 Network Performance Monitoring System")
st.write("Computer Communication Network (CCN) Microproject")

st.info(
    "This dashboard measures network latency, jitter, "
    "packet loss, and later, throughput."
)

st.sidebar.header("Test Settings")

host = st.sidebar.text_input(
    "Host to test",
    value="1.1.1.1"
)

packet_count = st.sidebar.slider(
    "Number of ping packets",
    min_value=5,
    max_value=20,
    value=5
)

st.subheader("📡 Run Network Test")

if st.button("▶ Start Measurement", type="primary"):
    if not host.strip():
        st.error("Please enter a valid host.")
    else:
        with st.spinner("Measuring network performance..."):
            result = measure_latency(
                host=host.strip(),
                count=packet_count
            )

        if result["latencies_ms"]:
            latencies = result["latencies_ms"]
            jitter = calculate_jitter(latencies)
            packet_loss = calculate_packet_loss(
                sent=packet_count,
                received=len(latencies)
            )

            average_latency = result["average_ms"]
            st.session_state["latest_latency"] = average_latency
            st.session_state["latest_jitter"] = jitter
            st.session_state["latest_packet_loss"] = packet_loss
            st.session_state["latest_host"] = host.strip()

            col1, col2, col3, col4 = st.columns(4)

            col1.metric(
                "Average Latency",
                f"{average_latency:.2f} ms"
            )

            col2.metric(
                "Jitter",
                f"{jitter:.2f} ms"
                if jitter is not None else "N/A"
            )

            col3.metric(
                "Packet Loss",
                f"{packet_loss:.1f}%"
            )

            col4.metric(
                "Successful Replies",
                f"{len(latencies)}/{packet_count}"
            )

            st.subheader("📊 Latency Measurements")

            df = pd.DataFrame({
                "Packet Number": range(1, len(latencies) + 1),
                "Latency (ms)": latencies
            })

            fig = px.line(
                df,
                x="Packet Number",
                y="Latency (ms)",
                markers=True,
                title="Latency for Each Successful Ping"
            )

            fig.update_layout(
                xaxis_title="Packet Number",
                yaxis_title="Latency (milliseconds)"
            )

            st.plotly_chart(fig, use_container_width=True)

            st.subheader("📋 Detailed Results")
            st.dataframe(df, use_container_width=True)

            st.write(
                f"**Minimum latency:** "
                f"{result['minimum_ms']:.2f} ms"
            )

            st.write(
                f"**Maximum latency:** "
                f"{result['maximum_ms']:.2f} ms"
            )

            st.write(
                f"**Failed replies (estimated):** "
                f"{packet_count - len(latencies)}"
            )

            st.caption(
                "Jitter is calculated as the average absolute "
                "difference between consecutive successful replies. "
                "Packet loss is calculated from the requested ping "
                "count and successful replies."
            )

        else:
            st.error(result["error"])
            st.warning(
                "The test did not receive ping replies. "
                "Check your internet connection, host, or firewall."
            )

st.divider()

st.subheader("📘 Understanding the Measurements")

st.markdown("""
- **Latency:** Time taken for a ping request to receive a reply.
- **Jitter:** Average change in latency between consecutive replies.
- **Packet Loss:** Percentage of requested ping packets that did not receive replies.
- **Throughput:** Amount of data transferred per second. We will implement this separately.
""")

st.caption("CCN Microproject | Network Performance Monitoring System")


st.divider()

st.subheader(" Throughput Measurement")

st.write(
    "Measure the download speed by downloading a small test file."
)

if st.button("▶ Measure Throughput"):
    with st.spinner("Measuring download throughput..."):
        throughput_result = measure_throughput()

    if throughput_result["error"] is None:
        col1, col2, col3 = st.columns(3)

        col1.metric(
            "Download Throughput",
            f"{throughput_result['throughput_mbps']:.2f} Mbps"
        )

        col2.metric(
            "Data Downloaded",
            f"{throughput_result['downloaded_bytes']:,} bytes"
        )

        col3.metric(
            "Download Duration",
            f"{throughput_result['duration_seconds']:.2f} seconds"
        )
        save_test_result(
            host=st.session_state.get("latest_host", host.strip()),
            latency_ms=st.session_state.get("latest_latency"),
            jitter_ms=st.session_state.get("latest_jitter"),
            packet_loss_percent=st.session_state.get("latest_packet_loss"),
            throughput_mbps=throughput_result["throughput_mbps"],
        )
        st.success("Throughput measurement completed.")

    else:
        st.error(
            "Throughput measurement failed: "
            + throughput_result["error"]
        )

st.caption(
    "Throughput depends on network conditions, "
    "server response, and download duration."
)


st.divider()

st.header("📚 Network Test History")

history_file = (
    Path(__file__).resolve().parent
    / "data"
    / "network_history.csv"
)

if history_file.exists():
    try:
        history_df = pd.read_csv(history_file)

        if history_df.empty:
            st.info(
                "No saved measurements yet. "
                "Run a latency test and then a throughput test."
            )
        else:
            st.subheader("📋 Saved Test Records")

            st.dataframe(
                history_df,
                use_container_width=True,
                hide_index=True
            )

            history_df["Date and Time"] = pd.to_datetime(
                history_df["Date and Time"],
                errors="coerce"
            )

            numeric_columns = [
                "Average Latency (ms)",
                "Jitter (ms)",
                "Packet Loss (%)",
                "Throughput (Mbps)"
            ]

            for column in numeric_columns:
                history_df[column] = pd.to_numeric(
                    history_df[column],
                    errors="coerce"
                )

            st.subheader("📈 Latency and Jitter Comparison")

            delay_df = history_df[
                ["Date and Time", "Average Latency (ms)", "Jitter (ms)"]
            ].dropna(subset=["Date and Time"])

            delay_long = delay_df.melt(
                id_vars=["Date and Time"],
                value_vars=[
                    "Average Latency (ms)",
                    "Jitter (ms)"
                ],
                var_name="Metric",
                value_name="Milliseconds"
            ).dropna(subset=["Milliseconds"])

            if not delay_long.empty:
                delay_fig = px.line(
                    delay_long,
                    x="Date and Time",
                    y="Milliseconds",
                    color="Metric",
                    markers=True,
                    title="Latency and Jitter Across Test Runs"
                )

                st.plotly_chart(
                    delay_fig,
                    use_container_width=True
                )
            else:
                st.info("No valid latency or jitter records to graph yet.")

            st.subheader("📦 Packet Loss Comparison")

            loss_df = history_df.dropna(
                subset=["Date and Time", "Packet Loss (%)"]
            )

            if not loss_df.empty:
                loss_fig = px.line(
                    loss_df,
                    x="Date and Time",
                    y="Packet Loss (%)",
                    markers=True,
                    title="Packet Loss Across Test Runs"
                )

                st.plotly_chart(
                    loss_fig,
                    use_container_width=True
                )
            else:
                st.info("No packet-loss records available to graph yet.")

            st.subheader("🚀 Throughput Comparison")

            speed_df = history_df.dropna(
                subset=["Date and Time", "Throughput (Mbps)"]
            )

            if not speed_df.empty:
                speed_fig = px.line(
                    speed_df,
                    x="Date and Time",
                    y="Throughput (Mbps)",
                    markers=True,
                    title="Download Throughput Across Test Runs"
                )

                st.plotly_chart(
                    speed_fig,
                    use_container_width=True
                )
            else:
                st.info("No throughput records available to graph yet.")

    except (OSError, ValueError, KeyError) as error:
        st.error(f"Could not read the history file: {error}")

else:
    st.info(
        "No history file exists yet. Run a latency test, "
        "then measure throughput to save a record."
    )


st.divider()

st.header("🔍 Network Performance Analysis")

if history_file.exists():
    try:
        analysis_df = pd.read_csv(history_file)

        if not analysis_df.empty:
            latest = analysis_df.iloc[-1]

            latency = pd.to_numeric(
                latest["Average Latency (ms)"],
                errors="coerce"
            )

            jitter = pd.to_numeric(
                latest["Jitter (ms)"],
                errors="coerce"
            )

            packet_loss = pd.to_numeric(
                latest["Packet Loss (%)"],
                errors="coerce"
            )

            throughput = pd.to_numeric(
                latest["Throughput (Mbps)"],
                errors="coerce"
            )

            st.write(
                "The following observations are based on "
                "the latest saved record."
            )

            if pd.notna(latency):
                if latency < 50:
                    st.success(
                        f"Latency is relatively low: {latency:.2f} ms."
                    )
                elif latency < 150:
                    st.info(
                        f"Latency is moderate: {latency:.2f} ms."
                    )
                else:
                    st.warning(
                        f"Latency is high: {latency:.2f} ms."
                    )

            if pd.notna(jitter):
                if jitter < 10:
                    st.success(
                        f"Jitter is low: {jitter:.2f} ms."
                    )
                elif jitter < 30:
                    st.info(
                        f"Jitter is noticeable: {jitter:.2f} ms."
                    )
                else:
                    st.warning(
                        f"Jitter is high: {jitter:.2f} ms."
                    )

            if pd.notna(packet_loss):
                if packet_loss == 0:
                    st.success("No packet loss was recorded in this test.")
                elif packet_loss < 2:
                    st.info(
                        f"Small packet loss was recorded: "
                        f"{packet_loss:.2f}%."
                    )
                else:
                    st.warning(
                        f"Packet loss may affect communication: "
                        f"{packet_loss:.2f}%."
                    )

            if pd.notna(throughput):
                st.write(
                    f"Measured download throughput: "
                    f"**{throughput:.2f} Mbps**."
                )

                st.caption(
                    "Higher throughput generally means more data can "
                    "be transferred per second. The required speed "
                    "depends on the application."
                )

    except (OSError, ValueError, KeyError) as error:
        st.error(f"Could not analyze the saved results: {error}")
else:
    st.info("Run and save a network test to generate an analysis.")
