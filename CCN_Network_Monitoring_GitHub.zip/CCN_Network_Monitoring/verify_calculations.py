
from network_monitor import (
    calculate_jitter,
    calculate_packet_loss,
)

print("NETWORK MONITORING - CALCULATION VERIFICATION")
print("=" * 50)

# Test 1: Jitter calculation
latencies = [20, 25, 22]
expected_jitter = 4.0
actual_jitter = calculate_jitter(latencies)

print("\nTest 1: Jitter")
print("Input latencies:", latencies)
print("Expected jitter:", expected_jitter, "ms")
print("Calculated jitter:", actual_jitter, "ms")
print("Result:", "PASS" if actual_jitter == expected_jitter else "FAIL")

# Test 2: Packet loss calculation
expected_loss = 20.0
actual_loss = calculate_packet_loss(sent=10, received=8)

print("\nTest 2: Packet Loss")
print("Packets sent: 10")
print("Packets received: 8")
print("Expected packet loss:", expected_loss, "%")
print("Calculated packet loss:", actual_loss, "%")
print("Result:", "PASS" if actual_loss == expected_loss else "FAIL")

# Test 3: No packet loss
no_loss = calculate_packet_loss(sent=10, received=10)

print("\nTest 3: No Packet Loss")
print("Expected packet loss: 0.0 %")
print("Calculated packet loss:", no_loss, "%")
print("Result:", "PASS" if no_loss == 0.0 else "FAIL")

# Test 4: Complete packet loss
complete_loss = calculate_packet_loss(sent=10, received=0)

print("\nTest 4: Complete Packet Loss")
print("Expected packet loss: 100.0 %")
print("Calculated packet loss:", complete_loss, "%")
print("Result:", "PASS" if complete_loss == 100.0 else "FAIL")

# Test 5: Insufficient latency values for jitter
single_latency = calculate_jitter([30])

print("\nTest 5: Single Latency Value")
print("Expected jitter: None")
print("Calculated jitter:", single_latency)
print("Result:", "PASS" if single_latency is None else "FAIL")

print("\nVerification completed.")
