
import platform
import re
import statistics
import subprocess
import time


import urllib.request

import csv
import os

def measure_throughput(
    url="https://speed.cloudflare.com/__down?bytes=1000000"
):
    """
    Estimate download throughput in megabits per second.
    Downloads a small test file from a public speed-test endpoint.
    """
    start_time = time.perf_counter()

    try:
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "CCN-Network-Monitor/1.0"}
        )

        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read()

        elapsed_time = time.perf_counter() - start_time

        if not data or elapsed_time <= 0:
            return {
                "throughput_mbps": None,
                "downloaded_bytes": len(data),
                "duration_seconds": elapsed_time,
                "error": "No data was downloaded."
            }

        throughput_mbps = (
            len(data) * 8 / elapsed_time
        ) / 1_000_000

        return {
            "throughput_mbps": throughput_mbps,
            "downloaded_bytes": len(data),
            "duration_seconds": elapsed_time,
            "error": None
        }

    except Exception as error:
        return {
            "throughput_mbps": None,
            "downloaded_bytes": 0,
            "duration_seconds": (
                time.perf_counter() - start_time
            ),
            "error": str(error)
        }

def measure_latency(host="1.1.1.1", count=5):
    """
    Measure response times using system ping.
    Returns successful response times in milliseconds.
    """
    system = platform.system().lower()

    if system == "windows":
        command = ["ping", "-n", str(count), "-w", "2000", host]
    else:
        command = ["ping", "-c", str(count), "-W", "2", host]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=count * 3 + 5
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return {
            "host": host,
            "latencies_ms": [],
            "error": "Ping timed out or the ping command was unavailable."
        }

    # Extract successful response times from ping output.
    latencies = re.findall(
        r"(?:time|time[=<])\s*[=<]?\s*(\d+(?:\.\d+)?)\s*ms",
        result.stdout,
        re.IGNORECASE
    )

    values = [float(value) for value in latencies]

    if not values:
        return {
            "host": host,
            "latencies_ms": [],
            "error": "No ping replies received. Check the host and network."
        }

    return {
        "host": host,
        "latencies_ms": values,
        "average_ms": statistics.mean(values),
        "minimum_ms": min(values),
        "maximum_ms": max(values),
        "error": None
    }


def calculate_jitter(latencies_ms):
    """
    Calculate average absolute difference between consecutive replies.
    """
    if len(latencies_ms) < 2:
        return None

    differences = [
        abs(latencies_ms[i] - latencies_ms[i - 1])
        for i in range(1, len(latencies_ms))
    ]

    return statistics.mean(differences)


def calculate_packet_loss(sent, received):
    """
    Calculate packet loss percentage.
    """
    if sent <= 0 or received < 0 or received > sent:
        raise ValueError("Invalid sent or received packet counts.")

    return ((sent - received) / sent) * 100


def save_test_result(
    host,
    latency_ms,
    jitter_ms,
    packet_loss_percent,
    throughput_mbps
):
    """Save one network test result to a CSV history file."""

    data_folder = "data"
    os.makedirs(data_folder, exist_ok=True)

    file_path = os.path.join(
        data_folder,
        "network_history.csv"
    )

    file_exists = (
        os.path.exists(file_path)
        and os.path.getsize(file_path) > 0
    )

    with open(
        file_path,
        mode="a",
        newline="",
        encoding="utf-8"
    ) as file:
        writer = csv.writer(file)

        if not file_exists:
            writer.writerow([
                "Date and Time",
                "Host",
                "Average Latency (ms)",
                "Jitter (ms)",
                "Packet Loss (%)",
                "Throughput (Mbps)"
            ])

        from datetime import datetime

        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            host,
            latency_ms,
            jitter_ms,
            packet_loss_percent,
            throughput_mbps
        ])
