from network_monitor import measure_throughput
from network_monitor import (
    calculate_jitter,
    calculate_packet_loss,
    measure_latency,
)

print("Testing Network Performance Monitor")
print("-" * 40)

latencies = [20.0, 25.0, 22.0]

jitter = calculate_jitter(latencies)
loss = calculate_packet_loss(sent=10, received=8)

print("Test latency values:", latencies, "ms")
print("Calculated jitter:", jitter, "ms")
print("Calculated packet loss:", loss, "%")

print("\nTesting actual network latency...")
result = measure_latency(host="1.1.1.1", count=5)

print("Host:", result["host"])

if result["latencies_ms"]:
    print("Successful replies:", len(result["latencies_ms"]))
    print("Average latency:", round(result["average_ms"], 2), "ms")
    print("Minimum latency:", round(result["minimum_ms"], 2), "ms")
    print("Maximum latency:", round(result["maximum_ms"], 2), "ms")
    print(
        "Jitter:",
        round(calculate_jitter(result["latencies_ms"]), 2)
        if calculate_jitter(result["latencies_ms"]) is not None
        else "Not enough replies",
        "ms"
    )
else:
    print("Measurement unavailable:", result["error"])

print("\nTest completed.")

print("\nTesting Download Throughput...")
throughput_result = measure_throughput()

if throughput_result["error"] is None:
    print(
        "Throughput:",
        round(throughput_result["throughput_mbps"], 2),
        "Mbps"
    )
    print(
        "Downloaded data:",
        throughput_result["downloaded_bytes"],
        "bytes"
    )
    print(
        "Download duration:",
        round(throughput_result["duration_seconds"], 2),
        "seconds"
    )
else:
    print(
        "Throughput test unavailable:",
        throughput_result["error"]
    )